package com.thinkofjava.messenger.service;

import java.util.List;

import com.thinkofjava.messenger.model.Message;
import com.thinkofjava.messenger.repository.MessageRepository;

public class MessageService {

	MessageRepository messageRepository = new MessageRepository();
	
	public List<Message> getAllMessages(){
		
		return messageRepository.getAllMessages();
	}
	
	public List<Message> getAllMessagesByYear(int year){
		return messageRepository.getAllMessagesByYear(year);
	}
	
	public List<Message> getAllMessagesByPagination(int start, int size){
		return messageRepository.getAllMessagesByPagination(start, size);
	}
	
	public Message getMessage(long messageId){
		return messageRepository.getMessage(messageId);
	}

	public Message addMessage(Message message){
		return messageRepository.addMessage(message);
	}
	
	public Message updateMessage(Message message){
		return messageRepository.updateMessage(message);
	}
	
	public Message deleteMessage(long messageId){
		return messageRepository.deleteMessage(messageId);
	}
}
