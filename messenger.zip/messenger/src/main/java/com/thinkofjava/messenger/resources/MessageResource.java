package com.thinkofjava.messenger.resources;

import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.thinkofjava.messenger.model.Message;
import com.thinkofjava.messenger.resources.beans.MessageResourceBean;
import com.thinkofjava.messenger.service.MessageService;

@Path("/messages")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MessageResource {

	MessageService messageService = new MessageService(); 
	
	
	/**
	 * This URI use to get all the message based on the provided query param
	 * 
	 * The URI for the below service could be
	 * /messages?year=2004   OR
	 * /messages?start=3&size=10  OR
	 * /messages?year=2018&start=2&size=20
	 * @MethodType = GET
	 * 
	 * If we do not pass the start and size value as query param
	 * then it will be initialized with default value.
	 * */
	@GET
	public List<Message> getMessage(@BeanParam MessageResourceBean messageBean){
		if(messageBean.getYear()>0){
			return messageService.getAllMessagesByYear(messageBean.getYear());
		}
		
		if(messageBean.getStart()>0 && messageBean.getSize()>0){
			return messageService.getAllMessagesByPagination(messageBean.getStart(), messageBean.getSize());
		}
		return messageService.getAllMessages();
	}

	
	/**
	 * This URI use to get single message by given message id
	 * 
	 * The URI for the below service could be
	 * /messages/124  OR
	 * /messages/anyValue
	 * 
	 * @MethodType = GET
	 * */
	@GET
	@Path("/{messageId}")
	public Message getMessage(@PathParam("messageId") long id){
	
		return messageService.getMessage(id);
	}
	
	
	/**
	 * This URI is use to create new message
	 * 
	 * @MethodType = POST
	 * @param 
	 * 			{
	 *			    "author": "Nagesh",
	 *			    "created": "2019-03-21T15:34:59.032Z[UTC]",
	 *			    "message": "This is a test message"
	 *			}
	 *
	 * @header:  Content-Type = application/json
	 * */
	@POST
	public Message addMessage(Message message){
		return messageService.addMessage(message);
	}
	

	/**
	 * This URI will delete the given message id
	 * 
	 * @MethodType = DELETE
	 * */
	@DELETE
	@Path("/{messageId}")
	public Message deleteMessage(@PathParam("messageId")long id){
		return messageService.deleteMessage(id);
	}

	
	/**
	 * This URI use to update the given message
	 * 
	 * @URI: /messages/{messageId}  where messageId can be any valid message id
	 * @MethodType: PUT
	 * @header:  Content-Type = application/json
	 * */
	@PUT
	@Path("{messageId}")
	public Message updateMessage(@PathParam("messageId") long messageId, Message message){
		message.setId(messageId);
		return messageService.updateMessage(message);
	}
	
	@Path("/{messageId}/comments")
	public CommentResource getCommentResource(){
		return new CommentResource();
	}
	
}
