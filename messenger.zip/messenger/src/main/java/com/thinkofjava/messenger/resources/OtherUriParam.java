package com.thinkofjava.messenger.resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

@Path("/test")
@Produces(MediaType.TEXT_PLAIN)
@Consumes(MediaType.TEXT_PLAIN)
public class OtherUriParam {
	
	/**
	 * The url for below service would be
	 * 
	 * /test/matrix;param=this_is_a_param
	 * 
	 * the value after semi-colon is known as matrix param
	 * */
	@GET
	@Path("matrix")
	public String getMatrixParam(@MatrixParam("param")String value){
		return "The given matrix param value is : "+value;
	}
	
	
	/**
	 * The uri for below service would be
	 * 
	 * /test/header
	 * 
	 * @header: customHeaderValue = anyHeaderValue
	 * */
	@GET
	@Path("header")
	public String getHeaderParam(@HeaderParam("customHeaderValue") String headerValue){
		return "Header value : "+headerValue;
	}
	
	
	@GET
	@Path("cookie")
	public String getCookieValue(@CookieParam("customCookie")String cookieValue){
		return "Cookie value: "+cookieValue;
	}
	
	/**
	 * Gives information about the URI
	 * */
	@GET
	@Path("uriinfo")
	public String getUriInfo(@Context UriInfo uriInfo){
		return "URI : "+uriInfo.getAbsolutePath();
	}
	
	@GET
	@Path("headerparam")
	public String getHeadersInfo(@Context HttpHeaders httpHeaders){
		return "Header params: "+httpHeaders.getRequestHeaders().toString()+"\n\n cookie param : "+httpHeaders.getCookies().toString();
	}
	
	@GET
	@Path("cookieinfo")
	public String getCookieInfo(@Context CookieParam cookieParam){
		return "Cookie params: "+cookieParam.toString();
	}
}
