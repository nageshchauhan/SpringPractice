package com.thinkofjava.messenger.repository;

import java.util.HashMap;
import java.util.Map;

import com.thinkofjava.messenger.model.Message;
import com.thinkofjava.messenger.model.Profile;

public class DatabaseClass {
	private static Map<Long, Message> messages = new HashMap<>();
	
	public static Map<String, Profile> profiles = new HashMap<>();
	
	static{
		messages.put(1L, new Message(1L,"Hello world!","Nagesh"));
		messages.put(2L, new Message(2L,"Hello Jersey","Nagesh"));
		
		profiles.put("nagesh", new Profile(1L,"nagesh","Nagesh","Chauhan"));
	}

	/**
	 * @return the messages
	 */
	public static Map<Long, Message> getMessages() {
		return messages;
	}


	/**
	 * @return the profiles
	 */
	public static Map<String, Profile> getProfiles() {
		return profiles;
	}

	
	
	
}
