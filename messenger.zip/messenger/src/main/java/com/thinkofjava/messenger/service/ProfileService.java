package com.thinkofjava.messenger.service;

import java.util.List;

import com.thinkofjava.messenger.model.Profile;
import com.thinkofjava.messenger.repository.ProfileRepository;

public class ProfileService {

	private ProfileRepository profileRepository = new ProfileRepository();
	
	public List<Profile> getAllProfile(){
		return profileRepository.getAllProfile();
	}
	
	public Profile getProfile(String profileName){
		return profileRepository.getProfile(profileName);
	}
	
	public Profile addProfile(Profile profile){
		return profileRepository.addProfile(profile);
	}
	
	public Profile updateProfile(Profile profile){
		return profileRepository.updateProfile(profile);
	}
	
	public Profile deleteProfile(String profileName){
		return profileRepository.deleteProfile(profileName);
	}
}
