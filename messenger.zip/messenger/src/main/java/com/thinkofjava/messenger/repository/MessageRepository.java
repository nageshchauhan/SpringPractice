package com.thinkofjava.messenger.repository;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import com.thinkofjava.messenger.model.Message;

public class MessageRepository {

	public static Map<Long, Message> messages = DatabaseClass.getMessages();
	
	public List<Message> getAllMessages(){
		return new ArrayList<Message>(messages.values());
	}
	
	public List<Message> getAllMessagesByYear(int year){
		List<Message> newMessage = new ArrayList<Message>();
		Calendar cal = Calendar.getInstance();
		for(Message message: messages.values()){
			cal.setTime(message.getCreated());
			if(cal.get(Calendar.YEAR)==year){
				newMessage.add(message);
			}
		}
		
		return newMessage;
	}
	
	public List<Message> getAllMessagesByPagination(int start, int size){
		if(start+size > messages.values().size()){
			return new ArrayList<Message>();
		}
		return new ArrayList<Message>(messages.values()).subList(start, start+size);
	}
	
	public Message getMessage(long messageId){
		return messages.get(messageId);
	}
	
	public Message addMessage(Message message){
		message.setId(messages.size()+1);
		messages.put(message.getId(), message);
		return message;
	}
	
	public Message updateMessage(Message message){
		if(message.getId()<=0){
			return null;
		}
		
		messages.put(message.getId(), message);
		
		return getMessage(message.getId());
	}
	
	public Message deleteMessage(long messageId){
		return messages.remove(messageId);
	}
}
