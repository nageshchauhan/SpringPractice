package com.thinkofjava.messenger.service;

import java.util.List;

import com.thinkofjava.messenger.model.Comment;
import com.thinkofjava.messenger.repository.CommentRepository;

public class CommentService {

	private CommentRepository commentRepository = new CommentRepository();
	
	public List<Comment> getAllComments(long messageId){
		return commentRepository.getAllComments(messageId);
	}
	
	public Comment getComment(long messageId, long commentId){
		return commentRepository.getCommentById(messageId, commentId);
	}
	
	public Comment addComment(long messageId, Comment comment){
		return commentRepository.addComment(messageId, comment);
	}
	
	public Comment updateComment(long messageId, long commentId, Comment comment){
		comment.setId(commentId);
		return commentRepository.updateComment(messageId, comment);
	}
	
	public Comment deleteComment(long messageId, long commentId){
		return commentRepository.removeComment(messageId, commentId);
	}
}
