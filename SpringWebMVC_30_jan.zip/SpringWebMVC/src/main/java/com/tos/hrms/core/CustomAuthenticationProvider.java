package com.tos.hrms.core;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.tos.hrms.bean.HrmsUser;
import com.tos.hrms.service.UserService;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider{

    private final UserService userService;
    
    @Autowired
    public CustomAuthenticationProvider(UserService userService){
        if(userService==null){
            throw new IllegalArgumentException("UserService can't be null in CustomAuthenticationProvider");
        }
        
        this.userService = userService;
    }
    
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) authentication;
        
        HrmsUser user = null;
        if(token.getName()!=null){
            user = userService.findUserByEmailId(token.getName());
        }
        
        if(user == null){
            throw new UsernameNotFoundException("Invalid username/password");
        }
        
        if(!user.getPassword().equals(token.getCredentials())){
            throw new BadCredentialsException("Invalid username / password");
        }
        //DaoAuthenticationProvider
        Collection<? extends GrantedAuthority> authority = UserAuthorityUtil.createAuthorities(user);
        
        return new UsernamePasswordAuthenticationToken(user, token.getCredentials(), authority);
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.equals(authentication);
    }

}
