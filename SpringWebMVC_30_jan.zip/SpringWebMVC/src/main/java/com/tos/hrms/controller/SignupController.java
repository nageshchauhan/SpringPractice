package com.tos.hrms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tos.hrms.bean.HrmsUser;
import com.tos.hrms.bean.SignupForm;
import com.tos.hrms.service.UserContext;
import com.tos.hrms.service.UserService;

@Controller
public class SignupController {

    private UserService userService;
    private UserContext userContext;
    
    @Autowired
    public SignupController(UserService userService, UserContext userContext){
        if(userService == null){
            throw new IllegalArgumentException("userService can't be null");
        }
        
        if(userContext == null){
            throw new IllegalArgumentException("userContext can't be null");
        }
        this.userService = userService;
        this.userContext = userContext;
    }
    
    @RequestMapping("/signup/form")
    public String signup(@ModelAttribute SignupForm signupForm) {
        return "signup/form";
    }
    
    @RequestMapping(value="/signup/new",method=RequestMethod.POST)
    public String signup(@Valid SignupForm signupForm, BindingResult result, RedirectAttributes redirectAttributes) {
        if(result.hasErrors()) {
            return "signup/form";
        }
        
        String email = signupForm.getEmail();
        
        if(userService.findUserByEmailId(email)!=null){
            result.rejectValue("email", "errors.signup.email","Email address is already in use");
            return "signup/form";
        }
        
        HrmsUser user = new HrmsUser(0, signupForm.getFirstName(), signupForm.getLastName(), email, signupForm.getPassword(),
                                     true, true, true, true);
        
        user.setId(userService.createUser(user));
        userContext.setCurrentUser(user);
        
        redirectAttributes.addFlashAttribute("message","You have been successfully signed up and logged in");
        return "redirect:/";
    }
    
}
