package com.tos.hrms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.tos.hrms.bean.HrmsUser;


public class HrmsUserRowMapper implements RowMapper<HrmsUser> {

    @Override
    public HrmsUser mapRow(ResultSet rs, int rowNum) throws SQLException {
        HrmsUser user = new HrmsUser(rs.getInt("user_id"),rs.getString("first_name"),rs.getString("last_name"),
                                     rs.getString("email"),rs.getString("password"), rs.getBoolean("is_account_non_expired"),
                                     rs.getBoolean("is_account_non_locked"),rs.getBoolean("is_credential_non_expired"),
                                     rs.getBoolean("is_enabled_account"));

        return user;
    }

}
