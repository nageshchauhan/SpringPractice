package com.tos.hrms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.tos.hrms.bean.HrmsUser;
import com.tos.hrms.query.SelectQuery;

@Repository
public class UserDaoImpl implements UserDao {

    private final JdbcOperations jdbcOperations;
    
    @Autowired
    public UserDaoImpl(JdbcOperations jdbcOperations) {
        if (jdbcOperations == null) {
            throw new IllegalArgumentException("jdbcOperations cannot be null");
        }
        this.jdbcOperations = jdbcOperations;
    }
    
    
    @Override
    public HrmsUser getUser(int id) {
        return jdbcOperations.queryForObject(SelectQuery.HRMS_USER_QUERY+"id = ?", new HrmsUserRowMapper(), new Object[]{id});
    }

    @Override
    public HrmsUser findUserByEmail(String email) {
        HrmsUser user = null;
        try{
            user = jdbcOperations.queryForObject(SelectQuery.HRMS_USER_QUERY+"email = ?", new HrmsUserRowMapper(), new Object[]{email});
        }catch(DataAccessException e){
            e.printStackTrace();
        }
        return user;
    }

    @Override
    public int createUser(final HrmsUser userToAdd) {
        if(userToAdd==null){
            throw new IllegalArgumentException("userToAdd cannot be null");
        }
        KeyHolder keyHolder = new GeneratedKeyHolder();
        
        jdbcOperations.update(new PreparedStatementCreator() {
            
            @Override
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(SelectQuery.HRMS_INSERT_QUERY, new String[] { "user_id" });
                ps.setString(1, userToAdd.getEmail());
                ps.setString(2, userToAdd.getPassword());
                ps.setString(3, userToAdd.getFirstName());
                ps.setString(4, userToAdd.getLastName());
                ps.setBoolean(5, true);
                ps.setBoolean(6, true);
                ps.setBoolean(7, true);
                ps.setBoolean(8, true);
                
                return ps;
            }
        }, keyHolder);
        
        return keyHolder.getKey().intValue();
    }

    @Override
    @Transactional(readOnly = true)
    public List<HrmsUser> findUsersByEmail(String partialEmail) {
        if (partialEmail == null) {
            throw new IllegalArgumentException("email cannot be null");
        }
        if ("".equals(partialEmail)) {
            throw new IllegalArgumentException("email cannot be empty string");
        }
        return jdbcOperations.query(SelectQuery.HRMS_USER_QUERY + "email like ? order by id", new HrmsUserRowMapper(), "%"+partialEmail + "%");
    }

}
