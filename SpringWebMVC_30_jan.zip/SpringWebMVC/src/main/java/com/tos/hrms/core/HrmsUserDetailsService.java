package com.tos.hrms.core;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.tos.hrms.bean.HrmsUser;
import com.tos.hrms.dao.UserDao;

@Component
public class HrmsUserDetailsService implements UserDetailsService{

    private final UserDao userDao;

    @Autowired
    public HrmsUserDetailsService(UserDao userDao) {
        if (userDao == null) {
            throw new IllegalArgumentException("userDao cannot be null");
        }
        this.userDao = userDao;
    }


    @Override
    public UserDetails loadUserByUsername(String username) {
        HrmsUser user = userDao.findUserByEmail(username);
        
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username/password.");
        }
        
        return new HrmsUserDetails(user);
    }
}

final class HrmsUserDetails implements UserDetails {
    /**
     * 
     */
    private static final long serialVersionUID = -1935801435798245895L;

    private HrmsUser user;
    
    HrmsUserDetails(HrmsUser user) { 
        this.user = user;
    }
    
    public String getName(){
        return user.getFirstName()+" "+user.getLastName();
    }

    public Collection<? extends GrantedAuthority> getAuthorities() { 
        return UserAuthorityUtil.createAuthorities(user); 
    } 

    public String getUsername() {
        return user.getEmail(); 
    }

    public boolean isAccountNonExpired() { 
        return user.isAccountNonExpired(); 
    } 
    
    public boolean isAccountNonLocked() { 
        return user.isAccountNonLocked(); 
    } 
    
    public boolean isCredentialsNonExpired() {
        return user.isCredentialsNonExpired(); 
    } 
    
    public boolean isEnabled() {
        return user.isEnabled(); 
    }

    @Override
    public String getPassword() {
        return user.getPassword();
    }
    
}