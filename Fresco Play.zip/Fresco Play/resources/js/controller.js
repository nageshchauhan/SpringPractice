//'use strict'();

springApp.controller("menuController", function ($scope) {

    $scope.firstName='';
    $scope.lastName="";
    $scope.contactList=undefined;
    $scope.createContact = function(){
        var contact = {};
        contact.firstName=$scope.firstName;
        contact.lastName=$scope.lastName;
        contact.id=new Date().getTime();
        console.log(contact);
        
        insertContact(contact);
        //resetForm();
    };
    
    
    function insertContact(contact){
        var id = firebase.database().ref().child('contacts').push().key;
        contact.id=id;
        firebase.database().ref('contacts/'+contact.id).set({
            id : contact.id,
            firstName : contact.firstName,
            lastName : contact.lastName
            
        },function(error){
            if(error){
                console.log("something went wrong "+error);
            }else{
                console.log("data inserted successfully");
                $scope.resetForm();
                $scope.reloadData();
            }
        });
    }

    $scope.resetForm=function(){
        console.log("reset form called");
        $scope.firstName='';
        $scope.lastName='';
    }
    
    $scope.reloadData=function(){
       
//        firebase.database().ref('contacts/').on('value',function(snapshot){
//            console.log("value from db"+snapshot.val());
//            $scope.contactList = snapshot.val();
//            console.log("contactList length "+ $scope.contactList);
//        },function(error){
//            console.log("error occured while reading data "+error);
//        });
    }
    
//    angular.element(document).ready(function () {
//        console.log('page loading completed');
//
//        firebase.database().ref('contacts/').on('value',function(snapshot){
//                console.log("db:"+snapshot.val());
//                $scope.contactList = snapshot.val();
//            },function(error){
//                console.log("error occured while reading data "+error);
//            });
//    });

    $scope.deleteContact = function(contactId){
        firebase.database().ref('contacts/'+contactId).remove();
        
    };
});