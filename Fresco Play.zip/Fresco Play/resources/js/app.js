var config = {
    apiKey: "AIzaSyBY2Cx0fK0JtWyYrG1ukj6AqjTEnXdY0JA",
    authDomain: "thinkofspring-io.firebaseapp.com",
    databaseURL: "https://thinkofspring-io.firebaseio.com",
    projectId: "thinkofspring-io",
    storageBucket: "thinkofspring-io.appspot.com",
    messagingSenderId: "881504148962"
};
firebase.initializeApp(config);

var springApp = angular.module("springApp", []);