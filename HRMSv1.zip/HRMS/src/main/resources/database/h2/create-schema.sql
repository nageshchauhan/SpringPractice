create table users(
	user_id int identity,
	first_name varchar(256),
	last_name varchar(256),
	created_on timestamp not null
);

create table user_cred(
	user_id int,
	user_name varchar(256),
	password varchar(256),
	last_reset timestamp
);